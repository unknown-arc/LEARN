# DBMS (MA 2205) — Assignment 5

This project is organized into three folders:

- `migrations/001_create_tables.sql` — creates the tables.
- `seeds/001_seed_assignment_data.sql` — inserts the student, faculty, enrollment, and class data.
- `queries/001.sql` to `queries/009.sql` — one assignment question and its SQL query per file.

## Run order

Run the files in this order in PostgreSQL:

1. `migrations/001_create_tables.sql`
2. `seeds/001_seed_assignment_data.sql`
3. `queries/001.sql` through `queries/009.sql`

## Note about the source PDF

The PDF provides data for the Student, Faculty, and Enrolled tables, but it does not show a Class table or class meeting details. The questions require class faculty, room, and meeting-time information, so the migration includes a `Class` table and the seed file adds illustrative class details for `CS101`, `CS102`, `Hist1`, and `Math1`. Those class details are assumptions for making the queries runnable; they are not supplied by the PDF. Student, faculty, and enrollment rows follow the PDF.

SQL dialect: PostgreSQL.
