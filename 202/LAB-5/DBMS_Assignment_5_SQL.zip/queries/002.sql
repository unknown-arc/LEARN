-- Q2. Find the age of the oldest student who is either a History major or is enrolled in a course taught by I. Teach.
SELECT MAX(s.age) AS oldest_age
FROM Student AS s
WHERE s.major = 'History'
   OR s.snum IN (
       SELECT e.snum
       FROM Enrolled AS e
       JOIN Class AS c ON c.cname = e.cname
       JOIN Faculty AS f ON f.fid = c.fid
       WHERE f.fname = 'I. Teach'
   );
