-- Q3. Find the names of all classes that either meet in room R128 or have five or more students enrolled.
SELECT c.cname
FROM Class AS c
WHERE c.room = 'R128'
   OR (
       SELECT COUNT(*)
       FROM Enrolled AS e
       WHERE e.cname = c.cname
   ) >= 5;
