-- Q5. Find the names of faculty members for whom the combined enrollment of the courses that they teach is less than five.
SELECT f.fname
FROM Faculty AS f
LEFT JOIN Class AS c ON c.fid = f.fid
LEFT JOIN Enrolled AS e ON e.cname = c.cname
GROUP BY f.fid, f.fname
HAVING COUNT(e.snum) < 5;
